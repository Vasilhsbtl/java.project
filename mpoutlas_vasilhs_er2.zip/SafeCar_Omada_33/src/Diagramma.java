public class Diagramma {
	public Katalogos_Diagrammatwn _unnamed_Katalogos_Diagrammatwn_;
	public Dimiourgia _unnamed_Dimiourgia_;
}