public class Xrhsths {
	public Pragmatognomwnas _unnamed_Pragmatognomwnas_;
	public Praktoras _unnamed_Praktoras_;
	public Ypallhlos _unnamed_Ypallhlos_;
	public Idiokthths _unnamed_Idiokthths_;
	public Dioikhtiko_Proswpiko _unnamed_Dioikhtiko_Proswpiko_;
	public Othoni_Syndesis _unnamed_Othoni_Syndesis_;
}