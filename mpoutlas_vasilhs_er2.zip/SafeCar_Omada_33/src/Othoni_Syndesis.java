public class Othoni_Syndesis {
	private String _kwdikos;
	private String _onoma;
	public Pragmatognomwnas _unnamed_Pragmatognomwnas_;
	public Praktoras _unnamed_Praktoras_;
	public Ypallhlos _unnamed_Ypallhlos_;
	public Idiokthths _unnamed_Idiokthths_;
	public Dioikhtiko_Proswpiko _unnamed_Dioikhtiko_Proswpiko_;
	public Xrhsths _unnamed_Xrhsths_;
	public Arxiki_Othoni _unnamed_Arxiki_Othoni_;

	public Othoni_Syndesis(String aKwdikos) {
        String pKwdikos=aKwdikos;
	}

	public Othoni_Syndesis(String aKwdikos, String aOnoma) {
        String pKwdikos=aKwdikos;
        String aOnoma=pOnoma;
    }

	public void setKwdikos(String aKwdikos) {
        String pKwdikos=aKwdikos;
	}

	public void setOnoma(String aOnoma) {
	   String   pOnoma=aOnoma;
	}
}