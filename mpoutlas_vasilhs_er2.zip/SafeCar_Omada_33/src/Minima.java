public class Minima {
	private String _epityxia;
	private String _apotyxia;
	private String _apodoxh;
	private String _aporripsi;
	public Anafora_Statistikwn _unnamed_Anafora_Statistikwn_;
	public Asfalish_Neou_Pelati _unnamed_Asfalish_Neou_Pelati_;
	public Asfalish_Neou_Pelati _unnamed_Asfalish_Neou_Pelati_2;
	public Periptwsh_Atyxhmatos _unnamed_Periptwsh_Atyxhmatos_;
	public Akyrwsh_Asfalishs_Pelati _unnamed_Akyrwsh_Asfalishs_Pelati_;

	public String Minima(String aEmfanise_epityxia) {
        String pEmfanise_epityxia=aEmfanise_epityxia;
	}

	public void setepityxia(String aEpityxia) {
        String pEpityxia=aEpityxia;
	}

	public void setapotyxia(String aApotyxia) {
        String pApotyxia=aApotyxia;
	}

	public void setapodoxh(String aApodoxh) {
         String pApodoxh=aApodoxh;
	}

	public void setaporripsi(String aAporripsi) {
		String pAporripsi=aAporripsi;
	}
}