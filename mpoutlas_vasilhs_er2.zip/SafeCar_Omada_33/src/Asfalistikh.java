public class Asfalistikh {
	private int _thlefwno;
	private String _email;
	private String _paketa;
	public Paketo_Asfalisis _unnamed_Paketo_Asfalisis_;

	public Asfalistikh(int aThlefwno) {
     int  pThlefwno=aThlefwno ;
	}

	public Asfalistikh(int aThlefwno, String aEmail) {
      int   pThlefwno = aThlefwno;
      String  pEmail = aEmail;
      }

	public Asfalistikh(int aThlefwno, String aEmail, String aPaketa) {
       int pThlefwno=aThlefwno;
       String pEmail=aEmail;
       String pPaketa=aPaketa;
	}

	public void setthlefwno(int aThlefwno) {
        int pThlefwno = aThlefwno ;
	}

	public void setemail(String aEmail) {
      String pEmail=aEmail;
	}

	public void setpaketa(String aPaketa) {
        String pPaketa = aPaketa;
	}
}