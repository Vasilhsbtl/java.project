public class Katalogos_Statistikwn_kai_posostwn {
	public ypologismos_statistikwn _unnamed_ypologismos_statistikwn_;
	public Parathiro_Epibebaiwshs _unnamed_Parathiro_Epibebaiwshs_;
}