public class Pelatis {
    private String onoma;
    private int afm;

    public Pelatis(String onoma, int afm) {
        this.onoma = onoma;
        this.afm = afm;
    }

    public String getOnoma() {
        return onoma;
    }

    public void setOnoma(String onoma) {
        this.onoma = onoma;
    }

    public int getAfm() {
        return afm;
    }

    public void setAfm(int afm) {
        this.afm = afm;
    }
}
