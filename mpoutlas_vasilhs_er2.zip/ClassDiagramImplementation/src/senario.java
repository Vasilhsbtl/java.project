public class Minima {
    private String epitixia;
    private String apotixia;

    public Minima(String epitixia, String apotixia) {
        this.epitixia = epitixia;
        this.apotixia = apotixia;
    }

    public String getEpitixia() {
        return epitixia;
    }

    public void setEpitixia(String epitixia) {
        this.epitixia = epitixia;
    }

    public String getApotixia() {
        return apotixia;
    }

    public void setApotixia(String apotixia) {
        this.apotixia = apotixia;
    }
}

x