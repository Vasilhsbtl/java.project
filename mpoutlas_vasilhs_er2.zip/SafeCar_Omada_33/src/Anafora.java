public class Anafora {
	public Katalogos_Anaforwn _unnamed_Katalogos_Anaforwn_;
}