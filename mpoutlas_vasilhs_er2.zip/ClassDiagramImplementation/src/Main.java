import java.util.Date;

public class Main {
    public static void main(String[] args) {
        // Δημιουργία πελατών
        Pelatis pelatis1 = new Pelatis("John Doe", 123456789);
        Pelatis pelatis2 = new Pelatis("Jane Smith", 987654321);

        // Δημιουργία οχημάτων
        Oxima oxima1 = new Oxima("AB1234", "Toyota Yaris");
        Oxima oxima2 = new Oxima("CD5678", "Honda Civic");

        // Δημιουργία ημερομηνιών
        Date enarxi1 = new Date(); // σημερινή ημερομηνία
        Date lixi1 = new Date(enarxi1.getTime() + (1000L * 60 * 60 * 24 * 365)); // ένα έτος μετά
        Date enarxi2 = new Date(); // σημερινή ημερομηνία
        Date lixi2 = new Date(enarxi2.getTime() + (1000L * 60 * 60 * 24 * 365)); // ένα έτος μετά

        // Δημιουργία ασφαλειών
        Asfaleia asfaleia1 = new Asfaleia(1, pelatis1, oxima1, enarxi1, lixi1, 300.00);
        Asfaleia asfaleia2 = new Asfaleia(2, pelatis2, oxima2, enarxi2, lixi2, 400.00);

        // Υπολογισμός στατιστικών
        YpologismosStatistikon stats = new YpologismosStatistikon();
        stats.ypologismosStatistikon(2, 0, 2); // 2 πελάτες με ασφάλεια, 0 ακυρωμένες, 2 νέες ασφάλειες

        // Εκτύπωση στατιστικών
        System.out.println("Πελάτες με ασφάλεια: " + stats.getPelatesMeAsfaleia());
        System.out.println("Ακυρωμένες ασφάλειες: " + stats.getAkyrwmenesAsfaleies());
        System.out.println("Νέες ασφάλειες: " + stats.getNeesAsfaleies());

        // Μηνύματα επιτυχίας και αποτυχίας
        Minima minima = new Minima("Επιτυχία", "Αποτυχία");
        System.out.println("Μήνυμα επιτυχίας: " + minima.getEpitixia());
        System.out.println("Μήνυμα αποτυχίας: " + minima.getApotixia());
    }
}
