public class Apostoli_Pragmatognomwna {
	public Periptwsh_Atyxhmatos _unnamed_Periptwsh_Atyxhmatos_;
	public Ekthesi_Pragratognomwna _unnamed_Ekthesi_Pragratognomwna_;
}