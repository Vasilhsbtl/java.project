public class YpologismosStatistikon {
    private int pelatesMeAsfaleia;
    private int akyrwmenesAsfaleies;
    private int neesAsfaleies;

    public YpologismosStatistikon() {
        this.pelatesMeAsfaleia = 0;
        this.akyrwmenesAsfaleies = 0;
        this.neesAsfaleies = 0;
    }

    public void ypologismosStatistikon(int pelates, int akyrwmenes, int nees) {
        this.pelatesMeAsfaleia = pelates;
        this.akyrwmenesAsfaleies = akyrwmenes;
        this.neesAsfaleies = nees;
    }

    public int getPelatesMeAsfaleia() {
        return pelatesMeAsfaleia;
    }

    public int getAkyrwmenesAsfaleies() {
        return akyrwmenesAsfaleies;
    }

    public int getNeesAsfaleies() {
        return neesAsfaleies;
    }

    public void setPelatesMeAsfaleia(int pelatesMeAsfaleia) {
        this.pelatesMeAsfaleia = pelatesMeAsfaleia;
    }

    public void setAkyrwmenesAsfaleies(int akyrwmenesAsfaleies) {
        this.akyrwmenesAsfaleies = akyrwmenesAsfaleies;
    }

    public void setNeesAsfaleies(int neesAsfaleies) {
        this.neesAsfaleies = neesAsfaleies;
    }
}
