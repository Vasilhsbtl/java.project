public class Parathiro_Epibebaiwshs {
	private String _oK;
	private String _apostolh;
	private String _egkrish;
	public Katalogos_Statistikwn_kai_posostwn _unnamed_Katalogos_Statistikwn_kai_posostwn_;
	public Ekthesi _unnamed_Ekthesi_;

	public String Parathiro_Epibebaiwshs(String aPataei_OK) {
		String pPataei_OK = aPataei_OK  ;
	}

	public void setOK(String aOK) {
        String pOK=aOK;
	}

	public void setapostolh(String aApostolh) {
        String pApostolh=aApostolh;
	}

	public void setegkrish(String aEgkrish) {
        String pEgkrish=aEgkrish;
	}
}