public class Ekthesi {
	public Parathyro_Egkrisis _unnamed_Parathyro_Egkrisis_;
	public Ekthesi_Pragmatognomwna _unnamed_Ekthesi_Pragmatognomwna_;
	public Parathiro_Epibebaiwshs _unnamed_Parathiro_Epibebaiwshs_;
}