public class Paketo_Asfalisis {
	public Epilogi_Paketou_Asfalishs _unnamed_Epilogi_Paketou_Asfalishs_;
	public Asfalish_Neou_Pelati _unnamed_Asfalish_Neou_Pelati_;
	public Asfalistikh _unnamed_Asfalistikh_;
}