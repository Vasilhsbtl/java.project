import java.util.Date;

public class Asfaleia {
    private int kwdikos;
    private Pelatis pelatis;
    private Oxima oxima;
    private Date imerominiaEnarxis;
    private Date imerominiaLiksis;
    private double poso;

    public Asfaleia(int kwdikos, Pelatis pelatis, Oxima oxima, Date imerominiaEnarxis, Date imerominiaLiksis, double poso) {
        this.kwdikos = kwdikos;
        this.pelatis = pelatis;
        this.oxima = oxima;
        this.imerominiaEnarxis = imerominiaEnarxis;
        this.imerominiaLiksis = imerominiaLiksis;
        this.poso = poso;
    }

    public int getKwdikos() {
        return kwdikos;
    }

    public void setKwdikos(int kwdikos) {
        this.kwdikos = kwdikos;
    }

    public Pelatis getPelatis() {
        return pelatis;
    }

    public void setPelatis(Pelatis pelatis) {
        this.pelatis = pelatis;
    }

    public Oxima getOxima() {
        return oxima;
    }

    public void setOxima(Oxima oxima) {
        this.oxima = oxima;
    }

    public Date getImerominiaEnarxis() {
        return imerominiaEnarxis;
    }

    public void setImerominiaEnarxis(Date imerominiaEnarxis) {
        this.imerominiaEnarxis = imerominiaEnarxis;
    }

    public Date getImerominiaLiksis() {
        return imerominiaLiksis;
    }

    public void setImerominiaLiksis(Date imerominiaLiksis) {
        this.imerominiaLiksis = imerominiaLiksis;
    }

    public double getPoso() {
        return poso;
    }

    public void setPoso(double poso) {
        this.poso = poso;
    }
}
