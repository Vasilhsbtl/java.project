public class Lista_Statistika_kai_pososta {
	private int _emfanise;
	public Kathgoria _unnamed_Kathgoria_;

	public Lista_Statistika_kai_pososta(int aEmfanise) {
       int pEmfanise=aEmfanise;
	}

	public void setemfanise(String aEmfanise) {
       String pEmfanise=aEmfanise;
	}
}