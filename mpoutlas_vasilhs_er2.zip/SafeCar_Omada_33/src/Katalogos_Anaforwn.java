public class Katalogos_Anaforwn {
	private int _kataxwrise;
	private int _emfanise;
	public Anafora _unnamed_Anafora_;
	public Dimiourgia _unnamed_Dimiourgia_;
	public Epikoinwnia_Me_Asfalistikh _unnamed_Epikoinwnia_Me_Asfalistikh_;

	private Katalogos_Anaforwn(int aKataxvrise) {
          int pKataxvrise=aKataxvrise;
	}

	public int Katalogos_Anaforwn(int aEmfanise) {
		int aEmfanise=pEmfanise;
	}

	public void setemfanise(String aEmfanise) {
		 String   pEmfanise = aEmfanise ;
	}

	public void setkataxvrise(String aEmfanise) {
		 String   pEmfanise=aEmfanise  ;
	}
}