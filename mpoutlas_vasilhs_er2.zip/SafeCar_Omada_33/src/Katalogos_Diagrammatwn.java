public class Katalogos_Diagrammatwn {
	public Anafora_Statistikwn _unnamed_Anafora_Statistikwn_;
	public Diagramma _unnamed_Diagramma_;
}