public class Stoixeia_Pelatwn_Oxhmatwn {
	private String _onomatepwnymo;
	private String _pinakides_oxhmatos;
	private String _marka_modelo;
	private int _aFM;
	public Ananewsh_Asfalisis_Pelati _unnamed_Ananewsh_Asfalisis_Pelati_;
	public Akyrwsh_Asfalishs_Pelati _unnamed_Akyrwsh_Asfalishs_Pelati_;
	public Katalogos_Stoixeiwn_Pelatwn_kai_oxhmatwn _unnamed_Katalogos_Stoixeiwn_Pelatwn_kai_oxhmatwn_;
	public Asfalisi_Neou_Pelati _unnamed_Asfalisi_Neou_Pelati_;
	public Pelaths _unnamed_Pelaths_;
	public Diaxeirish_Pelatwn_Oxhmatwn _unnamed_Diaxeirish_Pelatwn_Oxhmatwn_;
	public Periptwsh_Atyxhmatos _unnamed_Periptwsh_Atyxhmatos_;

	public Stoixeia_Pelatwn_Oxhmatwn(String aOnomatepwnymo) {
		 String pOnomatepwnymo=aOnomatepwnymo;
	}

	public Stoixeia_Pelatwn_Oxhmatwn(String aOnomatepwnymo, String aPinakides_oxhmatos) {
		 String pOnomatepwnymo=aOnomatepwnymo;
         String pPinakides_oxhmatos=aPinakides_oxhmatos;
	}

	public Stoixeia_Pelatwn_Oxhmatwn(String aOnomatepwnymo, String aPinakides_oxhmatos, String aMarka_modelo) {
		String aOnomatepwnymo=pOnomatepwnymo;
		String aPinakides_oxhmatos=pPinakides_oxhmatos;
		String aMarka_modelo=pMarka_modelo;
	}

	public Stoixeia_Pelatwn_Oxhmatwn(String aOnomatepwnymo, String aPinakides_oxhmatos, String aMarka_modelo, int aAFM) {
		String aOnomatepwnymo=pOnomatepwnymo;
		String aPinakides_oxhmatos=pPinakides_oxhmatos;
		String aMarka_modelo=pMarka_modelo;
		int aAFM=pAFM;
	}

	public void setOnomatepwymo(String aOnomatepwnymo) {
		String pOnomatepwnymo=aOnomatepwnymo;
	}

	public void setPinakides_oxhmatos(String aPinakides_oxhmatos) {
		String pPinakides_oxhmatos=aPinakides_oxhmatos;
	}

	public void setMarka_modelo(String aMarka_modelo) {
	    String	pMarka_modelo=aMarka_modelo;
	   }

	public void setAFM(String aAFM) {
		String pAFM= aAFM;   
	}
}