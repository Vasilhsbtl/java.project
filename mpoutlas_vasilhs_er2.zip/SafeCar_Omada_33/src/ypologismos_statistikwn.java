public class ypologismos_statistikwn {
	private int _pelates_me_atyxhmata;
	private int _akyrwmenes_asfaliseis;
	private int _nees_asfaliseis;
	private int _esoda;
	public Arxiki_Othoni _unnamed_Arxiki_Othoni_;
	public Dimiourgia _unnamed_Dimiourgia_;
	public Dimiourgia _unnamed_Dimiourgia_2;
	public Katalogos_Statistikwn_kai_posostwn _unnamed_Katalogos_Statistikwn_kai_posostwn_;

	public ypologismos_statistikwn(int aPelates_me_atyxhmata) {
		int pPelates_me_atyxhmata=aPelates_me_atyxhmata;
	}

	public ypologismos_statistikwn(int aPelates_me_atyxhmata, int aAkyrwmenes_asfaliseis) {
		int pPelates_me_atyxhmata=aPelates_me_atyxhmata;
		int pAkyrwmenes_asfaliseis=aAkyrwmenes_asfaliseis;
	}

	public ypologismos_statistikwn(int aPelates_me_atyxhmata, int aAkyrwmenes_asfaliseis, int aNees_asfaliseis) {
	  int 	pPelates_me_atyxhmata=aPelates_me_atyxhmata;
	  int   pAkyrwmenes_asfaliseis=aAkyrwmenes_asfaliseis;
	  int   pNees_asfaliseis=aNees_asfaliseis;
	}

	public ypologismos_statistikwn(int aPelates_me_atyxhmata, int aAkyrwmenes_asfaliseis, int aNees_asfaliseis, int aEsoda) {
		 int pNees_asfaliseis=aNees_asfaliseis ;
		 int pAkyrwmenes_asfaliseis=aAkyrwmenes_asfaliseis;
		 int pNees_asfaliseis= aNees_asfaliseis;
		 int pEsoda=aEsoda;
	}

	public void setpelates_me_atyxhmata(int aPelates_me_atyxhmata) {
		int pPelates_me_atyxhmata=aPelates_me_atyxhmata;
	}

	public void setakyrwmenes_asfaliseis(int aAkyrwmenes_asfaliseis) {
	    int pAkyrwmenes_asfaliseis=aAkyrwmenes_asfaliseis;
	}

	public void setnees_asfaliseis(int aNees_asfaliseis) {
	   int pNees_asfaliseis=aNees_asfaliseis;
	}

	public void setesoda(int aEsoda) {
		int pEsoda=aEsoda;
	}
}