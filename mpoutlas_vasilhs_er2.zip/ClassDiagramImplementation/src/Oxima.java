public class Oxima {
    private String arithmosKikloforias;
    private String markamontelo;

    public Oxima(String arithmosKikloforias, String markamontelo) {
        this.arithmosKikloforias = arithmosKikloforias;
        this.markamontelo = markamontelo;
    }

    public String getArithmosKikloforias() {
        return arithmosKikloforias;
    }

    public void setArithmosKikloforias(String arithmosKikloforias) {
        this.arithmosKikloforias = arithmosKikloforias;
    }

    public String getMarkamontelo() {
        return markamontelo;
    }

    public void setMarkamontelo(String markamontelo) {
        this.markamontelo = markamontelo;
    }
}
