public class Dimiourgia {
	private String _emfanise;
	public Diagramma _unnamed_Diagramma_;
	public ypologismos_statistikwn _unnamed_ypologismos_statistikwn_;
	public ypologismos_statistikwn _unnamed_ypologismos_statistikwn_2;
	public Ypologismos_statistikwn _unnamed_Ypologismos_statistikwn_;
	public Katalogos_Anaforwn _unnamed_Katalogos_Anaforwn_;

	public Dimiourgia(int aEmfanise) {
       int pEmfanise = aEmfanise ;
       }

	public void setemfanise(String aEmfanise) {
       String pEmfanise=aEmfanise;	}
}